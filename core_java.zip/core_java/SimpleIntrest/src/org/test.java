package org;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    SimpleIntrest si1=new SimpleIntrest();
    si1.principle=1000;
    si1.rate=2;
    si1.time=2;
    
   si1.display();
	}

}
