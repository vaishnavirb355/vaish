package org;

public class SimpleIntrest {
	public int principle,rate,time;
	
	public void intrest()
	{
		float amount=(principle*rate*time)/100;
		System.out.println("The calculated amount"+" "+amount);
	}

	
	
	public void display() 
	{
		System.out.println("printing the data");
		System.out.println("principle="+principle);
		System.out.println("rate="+rate);
		System.out.println("time="+time);
		intrest();
		
	}
}
