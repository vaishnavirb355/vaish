
package myfirstApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class MyApplication {
	public static void main(String[] args) 
	{
		try {
			Scanner scn=new Scanner(System.in);
		 String uname="root";
		 String pass="1234";
		 String url="jdbc:mysql://localhost:3306/examples?useSSL=false";
		 Class.forName("com.mysql.cj.jdbc.Driver");	
		 Connection con=DriverManager.getConnection(url,uname,pass);
		 System.out.println("**************************************Welcome to the application**************************************");
		 System.out.println("-------------------------------------------LOGIN PAGE--------------------------------------------------------");
		 
		 //enter the username
		 System.out.println("Enter the username");
		 String temp_name=scn.next();
		 System.out.println("Enter the password");
		 String temp_pass=scn.next();
		 String query="select *from application";
		 Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery(query);
		 
		 //enter the password
		
		while( rs.next())
		{
		 if(((rs.getString("user").equals(temp_name))&&(rs.getString("password").equals(temp_pass))))
		 {
			 int choice=0;
			 System.out.println("VALID USER");
			 System.out.println("******________MENU________*******");
			 System.out.println("Please enter the choice from 1-4");
			 System.out.println("1-List the Records");
			 System.out.println("2-Add a new record");
			 System.out.println("3-Update an existing record");
			 System.out.println("4-Show details");
			 choice=scn.nextInt();
			 switch(choice)
			 {
			 case 1:System.out.println("Listing the records ");
			        ListMethod();
			         break;
			 case 2:System.out.println("adding the records ");
			        AddMethod();
			        break;
			 case 3:System.out.println("updating the records ");
			        UpdateMethod();
			        break;
			 case 4:System.out.println("showing your details");
			        Selecting();
			        break;
			 default:System.out.println("Exiting");
			        break;
			 }
		 }
		 else
		 {
			 System.out.println("Invalid user");
			 break;
		 }
		 }
		
		
		
		}
		catch(Exception e)
		{
		System.out.println(e);	
		}	
		
	}
	public static void ListMethod()
	{
		try {
			 String uname="root";
			 String pass="1234";
			 String url="jdbc:mysql://localhost:3306/examples?useSSL=false";
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 Connection con=DriverManager.getConnection(url,uname,pass);
			 String query="select * from customer";
			 Statement st=con.createStatement();
			 ResultSet rs=st.executeQuery(query);
			 while(rs.next())
			 {
				 int id=rs.getInt("id");
				 String name=rs.getString("name");
				 String address=rs.getString("address");
				 System.out.println(id+" "+name+" "+address);
			 }
		 }
		 catch(Exception e)
		 {
			System.out.println(e); 
		 }
		
	}
	
	public static void AddMethod()
	{
		try 
		{ int n=0;
		 Scanner scn=new Scanner(System.in);
			String uname="root";
			 String pass="1234";
			 String url="jdbc:mysql://localhost:3306/examples?useSSL=false";
			 Class.forName("com.mysql.cj.jdbc.Driver");	
			 Connection con=DriverManager.getConnection(url,uname,pass);
			 String query="select max(id) from customer";
			 Statement st=con.createStatement();
			 ResultSet rs=st.executeQuery(query);
			 rs.next();
			 int temp=rs.getInt(1);
			 System.out.println("how many records to add?");
			 n=scn.nextInt();
			 for(int i=1;i<=n;i++)
			 {
				 temp++;
			 System.out.println("Enter the customer "+i+ " name ");
			 String name=scn.next();
			 System.out.println("Enter the customer "+i+" address ");
			 String address=scn.next();
			 String query1="insert into customer values ("+temp+",'"+name+"','"+address+"')";
			 Statement st1=con.createStatement();
			 st1.executeUpdate(query1);
	        }
		}
		catch(Exception e)
		 {
			System.out.println(e); 
		 }
	}
  public static void UpdateMethod()
  {
	  try 
		{ 
		 Scanner scn=new Scanner(System.in);
			String uname="root";
			 String pass="1234";
			 String url="jdbc:mysql://localhost:3306/examples?useSSL=false";
			 Class.forName("com.mysql.cj.jdbc.Driver");	
			 Connection con=DriverManager.getConnection(url,uname,pass);
			 System.out.println("Please enter the id you want to update details");
			 int input=scn.nextInt();
			 System.out.println("Please enter the name you want to update");
			 String inname=scn.next();
			 System.out.println("Please enter the address you want to update");
			 String inadd=scn.next();
			 String query="Update customer set name='"+inname+"', address='"+inadd+"' where id="+input;
			 //"Update customer set name='inname'and address='inadd' where id=+input;
			 Statement st=con.createStatement();
		     st.executeUpdate(query);
		     System.out.println("----------------------success-----------------------");
		     System.out.println("Record updated");
		}
	  catch(Exception e)
	  {
		  System.out.println(e); 
	  }
  }
	
	
  public static void Selecting()
  {
	  try {
	  String uname="root";
		String pass="1234";
		 String url="jdbc:mysql://localhost:3306/examples?useSSL=false";
	  Class.forName("com.mysql.cj.jdbc.Driver");	
	  Connection con=DriverManager.getConnection(url,uname,pass);
	  
	  
  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
  }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
