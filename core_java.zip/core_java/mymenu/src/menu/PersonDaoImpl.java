package menu;
 
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
public class PersonDaoImpl implements PersonDao
{
	Connection con=null;
	Statement st1=null;
	Statement st2=null;
	ResultSet rs=null;
	
	private Connection getConnection() throws SQLException
	{
		Connection con;
		con=ConnectionFactory.getInstance().getConnection();
		return con;
	}
	
	public List<Person> getAllperson()
	{
		List<Person> listOfPerson=new ArrayList<Person>();
		try {
			con=getConnection();
			String query="select * from info";
			st1=con.createStatement();
			ResultSet rs=st1.executeQuery(query);
			while(rs.next())
			{
				String tempname=rs.getString(1);
				int tempid=rs.getInt(2);
				String tempemail=rs.getString(3);
				String tempdob=rs.getString(4);
				int tempphone=rs.getInt(5);
				String tempadd=rs.getString(6);
				listOfPerson.add(new Person(tempname,tempid,tempemail,tempdob,tempphone,tempadd));
				
			}
			
		}
		catch(Exception e)
		{
			
		}
		return listOfPerson;
	}

	@Override
	public void addPerson() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Person> getAllPerson() {
		// TODO Auto-generated method stub
		return null;
	}

}
