package menu;
import java.util.List;

public interface PersonDao {
	public void addPerson();
	public List<Person> getAllPerson();
}
