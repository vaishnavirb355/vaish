package menu;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class ConnectionFactory {
		String connectionurl = "jdbc:mysql://localhost:3306/vaishnavi?useSSL=false";
		String dbuser = "root";
		String dbPwd = "1234";
		String driverClassName = "com.mysql.cj.jdbc.Driver";

		private static ConnectionFactory connectionfactory = null;

		private ConnectionFactory() {
			try {
				Class.forName(driverClassName);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		public Connection getConnection() throws SQLException
		{
			Connection con=null;
			con=DriverManager.getConnection(connectionurl, dbuser,dbPwd);
			return con;
		}
		 
		public static  ConnectionFactory getInstance()
		{
			if(connectionfactory==null)
			{
				connectionfactory=new ConnectionFactory();
			}
			return connectionfactory;
		}
	}

