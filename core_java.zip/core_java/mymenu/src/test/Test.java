package test;

import menu.PersonDaoImpl;

public class Test {
	public static void main(String[] args) {
		PersonDaoImpl person=new PersonDaoImpl();
		(person.getAllperson()).stream().forEach(p->System.out.println("***"+p.id+"---"+p.name+"----"+p.email+"----"+p.dob+"-----"+p.phone+"----"+p.address));
	}

}
