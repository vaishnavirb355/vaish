package Testconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class insertdata {

	public static void main(String[] args) {
		try 
		{ int n=0;
		 Scanner scn=new Scanner(System.in);
			String uname="root";
			 String pass="1234";
			 String url="jdbc:mysql://localhost:3306/examples?useSSL=false";
			 Class.forName("com.mysql.cj.jdbc.Driver");	
			 Connection con=DriverManager.getConnection(url,uname,pass);
			 String query="select max(id) from customer";
			 Statement st=con.createStatement();
			 ResultSet rs=st.executeQuery(query);
			 rs.next();
			 int temp=rs.getInt(1);
			 System.out.println("how many records to update?");
			 n=scn.nextInt();
			 for(int i=1;i<=n;i++)
			 {
				 temp++;
			 System.out.println("Enter the customer "+i+ " name ");
			 String name=scn.next();
			 System.out.println("Enter the customer "+i+" address ");
			 String address=scn.next();
			 String query1="insert into customer values ("+temp+",'"+name+"','"+address+"')";
			 Statement st1=con.createStatement();
			 st1.executeUpdate(query1);
			 }
			 
			 /*while(rs.next())
			 {
				 int id=rs.getInt("id");
				 String name=rs.getString("name");
				 String address=rs.getString("address");
				 System.out.println(id+" "+name+" "+address);
			 }*/
			 
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
