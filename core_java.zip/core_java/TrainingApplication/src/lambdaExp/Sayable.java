package lambdaExp;

public interface Sayable {
	//public String say(String name);
    public void say();
	//public String say();

}
