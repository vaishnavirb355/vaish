package lambdaExp;
/*import java.util.Scanner;*/
import java.util.function.*;

public class TestWithoutLambda {
 

	public static void main(String[] args) {
		/*Scanner scn=new Scanner(System.in);
		int x =0,y=0;
		*/
		/* int width = 10; */

		/*
		 * Drawable d=new Drawable() { public void draw() {
		 * System.out.println("Darwing"+width); } }; d.draw();
		 */

		/*
		 * Drawable d = () -> { System.out.println("Drawing" + width); }; d.draw();
		 */
    /*  Addable add1=(a,b)->(a+b);
      System.out.println("enter the value for x and y");
      scn.nextInt();
      System.out.println(add1.add(x,y));
     
      
      Addable add2=(int a,int b)->(a+b);
      System.out.println(add2.add(130,250));
		
		*/
		/*
		 * Sayable s=(message)->{ String str1="hey there, "; String str2=str1+message;
		 * return str2; }; System.out.println(s.say("have a good day"));
		 * 
		 */
		InstanceMethodExample methodReference=new InstanceMethodExample();
		Sayable sayable= methodReference::saysomething;
		sayable.say();
		
		Sayable sayable2= new InstanceMethodExample()::saysomething;
		sayable2.say();
		
		
	}

}
