package lambdaExp;

public class InstanceMethod {

}
