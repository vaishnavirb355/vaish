package lambdaExp;

public class InstanceMethodExample {
		public void
		saysomething()
		{
			System.out.println("hey");
		}
		

}
