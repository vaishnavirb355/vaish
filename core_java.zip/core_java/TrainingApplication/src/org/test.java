package org;

public class test {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
     Student s1= new Student();
     s1.name="vaishnavi";
     s1.age=21;
     s1.address="Mangalore";
     s1.s_display();
     
     Teacher t1= new Teacher();
     t1.tname="UPPU";
     t1.course_name="java";
     t1.course_no=01;
     t1.t_display();
     
     
	}

}
