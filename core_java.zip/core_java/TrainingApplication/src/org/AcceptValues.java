package org;
import java.util.Scanner;

public class AcceptValues {

	public static void main(String[] args)
	{
		Scanner scn=new Scanner(System.in);
		System.out.println("Enter the name");
		String name= scn.next();
		System.out.println("Enter the age");
		int age=scn.nextInt();
		System.out.println("Enter the CGPA");
		float cgpa=scn.nextFloat();
		System.out.println("Name="+name);
		System.out.println("Age="+age);
		System.out.println("Cgpa="+cgpa);
		
		
	}

}
