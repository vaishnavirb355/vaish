package org;

public class Student {
	public String name;
	public int age;
	public String address;

	
	public  void s_display()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(address);
	}
}
