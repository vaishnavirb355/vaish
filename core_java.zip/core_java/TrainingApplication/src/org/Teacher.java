package org;

public class Teacher {
	public String tname;
	public String course_name;
	public int course_no;

	
	public void t_display() 
	{
	  System.out.println(tname);	
	  System.out.println(course_name);
	  System.out.println(course_no);	
	}
}
