package poly;

public interface Washable {
  public void wash();
}
