package poly;

public class Liquid {
   public void swirl()
   {
	   System.out.println("swirling Liquid");
   }
}
