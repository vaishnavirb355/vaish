package poly;

public class Test {

	public static void main(String[] args) {
		Liquid l=new Liquid();
		Coffee c=new Coffee();
		Tea t=new Tea();
		Mug m=new Mug();
		m.addLiquid(t);
       m.wash();
       m.paint();
       int num[]=new int[5];
	}

}

