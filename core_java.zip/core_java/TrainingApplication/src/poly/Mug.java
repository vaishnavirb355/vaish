package poly;

public class Mug implements Paintable,Washable {
	public void addLiquid(Liquid l)
	{
		if(l instanceof Coffee)
		{
			System.out.println("you have choosen coffee");
			
		}
		else if(l instanceof Tea)
		{
			System.out.println("you have choosen tea");
			
		}
		else
		{
			System.out.println("you have choosen some other liquid");
			
		}
	}
	public void wash()
	{
		System.out.println("the mug can be washable");
	}
	
	public void paint()
	{
		System.out.println(" the mug can be paintable as well");
	}

}
