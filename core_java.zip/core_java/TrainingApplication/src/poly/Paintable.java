package poly;

public interface Paintable {
 public void paint();
}
