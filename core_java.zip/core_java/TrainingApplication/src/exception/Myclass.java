package exception;

public class Myclass {
	//handling the excpetion
	public void method1()
	{
		try {
			int z=10/0;
			int[] x= new int[5];
			x[6]=20;
		}catch(ArithmeticException e)
		{
			System.out.println("the number divided by zero leads to infinity");
		}catch(IndexOutOfBoundsException e) {
			System.out.println("");
		}
		
	}
	   
	
	//declaring the exception
	public void method2()
	{
		int x=10;
		int y=3;
		int z=10/0;
	}

}
