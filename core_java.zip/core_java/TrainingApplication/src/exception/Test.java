package exception;

public class Test {

	public static void main(String[] args) {
		Myclass obj=new Myclass();
		obj.method1();
		try
		{
			obj.method2();
		}catch(Exception e)
		{
			System.out.println("the number divide by zero leads to infinity");
		}finally
		{
			System.out.println("The block has to continue execution");
		}
		
 
	}

}
