package collection;
import java.util.*;

public class CollectionTest {
	 
	public void hashsetExample()
	{
		HashSet<String> hset=new HashSet<String>();
		hset.add("Mango");
		hset.add("Orange");
		hset.add("PineApple");
		hset.add("Apple");
		hset.add("Chikku");
		hset.add("Apple");
		hset.add("Mango");
		hset.add(null);
		hset.add(null);
		System.out.println(hset);
		
	}
	public void tressetExample() 
	{
		TreeSet<String> al=new TreeSet<String>();
		al.add("aaa");
		al.add("bbb");
		al.add("ccc");
		al.add("ddd");
		al.add("eee");
		
		Iterator<String> itr=al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}
	public void listExample()
	{
		List<String> l=new ArrayList<String>();
		l.add("AAA");
		l.add("BBB");
		l.add("CCC");
		l.add(1,"DDD");
		System.out.println("2nd Element"+l.get(2));
		for(String s:l)
		{
			System.out.println(s);
		}
	}
	
	public void queueExample() 
	{
	  Queue<String> q=new PriorityQueue<String>();
	  q.add("MMMM");
	  q.add("LLLL");
	  q.add("WWWW");
	  q.add("RRRR");
	  System.out.println("head"+" "+q.element());
	  System.out.println("head"+" "+q.peek());
	  System.out.println("Before Iterating the queue elements");
	  
	  Iterator<String> itr1=q.iterator();
	  while(itr1.hasNext())
	  {
		  System.out.println(itr1.next());
	  }
	  q.remove();
	  q.poll();
	  System.out.println("After Iterating the queue elements");
	  Iterator<String> itr2=q.iterator();
	  while(itr2.hasNext())
	  {
		  System.out.println(itr2.next());
	  }
	}
	
	public void linkedExample()
	{
		LinkedList<String> ll=new LinkedList<String>();
		ll.add("TTTT");
		ll.add("UUUU");
		ll.add("HHHH");
		Iterator<String> itr3=ll.iterator();
		  while(itr3.hasNext())
		  {
			  System.out.println(itr3.next());
		  }	
	}

	
	public void VectorExample()
	{
	 Vector<String> v=new Vector<String>();
	 v.add("QQQQ");
	 v.add("XXXX");
	 v.add("YYYY");
	 v.add("ZZZZ");
	 Iterator<String> itr4=v.iterator();
	  while(itr4.hasNext())
	  {
		  System.out.println(itr4.next());
	  }	
	}
	
	public void StackExample()
	{
	 Stack<String> stack=new Stack<String>();
	 stack.push("IIII");
	 stack.push("KKKK");
	 stack.push("FFFF");
	 stack.push("OOOO");
	 stack.pop();
	 Iterator<String> itr5=stack.iterator();
	  while(itr5.hasNext())
	  {
		  System.out.println(itr5.next());
	  }	
	}
	
	
	public void MapExample()
	{
		Map<Integer,String> m=new HashMap<Integer,String>();
		m.put(100,"AAAA");
		m.put(101,"BBBB");
		m.put(102,"CCCC");
		m.put(103,"DDDD");
		
		for(Map.Entry me:m.entrySet())
		{
			System.out.println(me.getKey()+" "+me.getValue());
		}
		
	}
	 public static void main(String[] args) 
	 {
		
		 CollectionTest obj=new CollectionTest();
		 obj.hashsetExample();
		 obj.tressetExample();
		 obj.listExample();
		 obj.queueExample();
		 obj.linkedExample();
		 obj.VectorExample();
		 obj.StackExample();
		 obj.MapExample();
		  
	}

}
