package serialisation;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SaveStudent {

	public static void main(String[] args) {
		try 
		{
			Student s1=new Student(101,"vaishnavi");
			FileOutputStream fout=new FileOutputStream("C:\\vaishnavi\\core_java\\student.txt");
			ObjectOutputStream out= new ObjectOutputStream(fout);
			out.writeObject(s1);
			out.flush();    //closing the stream
			out.close();   //closing the file
			System.out.println("object saved");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
	}

}
