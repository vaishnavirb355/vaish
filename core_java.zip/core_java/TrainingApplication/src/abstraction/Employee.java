package abstraction;

public class Employee {
	
 public void doSomething()
{
 	 System.out.println("employee constructor");
   }
}
