package abstraction;

public class Student {
  public void doSomething() {
	  System.out.println("student constructor");
  }
}
