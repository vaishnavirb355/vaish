package abstraction;

public class Test {

	public static void main(String[] args) {
		Employee e=new Employee();
		e.doSomething();
		
		Student s=new Student();
		s.doSomething();
	}

}
