package abstraction;

public abstract class Person {
	public String name;
	public int age;
	
	public abstract void doSomething();

}
