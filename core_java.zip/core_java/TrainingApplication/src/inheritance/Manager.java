package inheritance;

public class Manager extends Employee {
	public String dept;
	
	public Manager(String name,int age,int empid,String dept)
	{
		super(name,age,empid);
		this.dept=dept;
		/*System.out.println("this is the employee constructor");*/
	}

}
