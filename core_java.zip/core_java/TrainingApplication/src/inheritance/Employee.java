package inheritance;

public class Employee extends Person {
	public int empid;
    public Employee(String name,int age,int empid)
    {
    	super(name,age);
    	this.empid=empid;
    }
}
