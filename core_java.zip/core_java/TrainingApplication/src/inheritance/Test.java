package inheritance;

public class Test {

	public static void main(String[] args) {
		Manager m= new Manager("vcvv",23,101,"HR");
		/*System.out.println("this is the manager constructor");*/
		System.out.println(m.name+" "+m.age+" "+m.empid+" "+m.dept);
       
	}

}
