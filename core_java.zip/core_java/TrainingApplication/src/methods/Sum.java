package methods;

public class Sum {
	int a;float b;
	public void sum()
	{
		System.out.println("result "+(a+b));
	}
	public float sum1()
	{
		return a+b;
	}
	public int sum2(int a,int b)
	{
		int result1=a+b;
		return result1;
	}
	public float sum3(int a,float b)
	{
		float result2=a+b;
		return result2;
	}
  
}
