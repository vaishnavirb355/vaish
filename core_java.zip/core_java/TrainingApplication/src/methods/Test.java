package methods;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
	
	   Sum obj=new Sum();
	  Scanner scn =new Scanner(System.in);
	    System.out.println("enter the first value");
	    obj.a=scn.nextInt();
	    System.out.println("enter the second value");
	    obj.b=scn.nextFloat();
	    
	    obj.sum();
	    float value=obj.sum1();
		System.out.println("The result is "+value);
	    /*int value1=obj.sum2(obj.a,obj.b);
		System.out.println("The result is "+value1);*/
	    float value2=obj.sum3(obj.a,obj.b);
	    System.out.println("The result is "+value2);
	}

}
