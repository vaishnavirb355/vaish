package array;
import java.util.Scanner;
public class ArrayExample {
	public static void main(String[] args) {
		/*int[] num;
		num=new int[5];
		num[0]=10;
		num[1]=20;
		num[2]=30;
		num[3]=40;
		num[4]=50;
		
		String[] names = {"aaaa","nbbb","cccc","dddd"};
		for (String i:names)
		{
			System.out.println(i);
		}
		 for(int i=0;i<num.length;i++)
		 {
			 System.out.println(num[i]);
		 }*/
		 int[][] matrix;
		 matrix=new int[2][2];
		 System.out.println(" enter the values "); 
		 Scanner scn=new Scanner(System.in);
		 for(int i=0;i<2;i++)
		 {
			 for(int j=0;j<2;j++)
			 {
				 matrix[i][j]=scn.nextInt();
			 }
		 }
		 
		 System.out.println("Matrix"); 
		 for(int i=0;i<2;i++)
		 {
			 for(int j=0;j<2;j++)
			 {
				 System.out.println(matrix[i][j]+" ");
			 }
		 }
		 
		 
		 
		 
		 
		 
		}
}

