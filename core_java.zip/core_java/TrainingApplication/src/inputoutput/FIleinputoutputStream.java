package inputoutput;

import java.io.FileOutputStream;
import java.io.FileInputStream;


public class FIleinputoutputStream {
	public static void main(String[] args) {
		try {
			FileOutputStream fout=new FileOutputStream("C:\\vaishnavi\\core_java\\iostream.txt");
			String s="hey there,welcome";
			byte b[]=s.getBytes();
			fout.write(b);
			fout.close();
			System.out.println("file is created");
		}catch(Exception e)
		{
		 System.out.println(e);	
		}
		try 
		{
			FileInputStream fin=new FileInputStream("C:\\vaishnavi\\core_java\\iostream.txt");
			int i=0;
			while((i=fin.read())!=-1)
			{
				System.out.print(((char)i));			
				
			}
			fin.close();
		}
		catch(Exception e)
		{
		 	System.out.println(e);
		}
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
