package functionInterface;
import java.util.function.*;

public class Predictor {
	public static void main(String[] args) {
		Predicate<Integer> p= a->(a>18);
		System.out.println(p.test(10));
	}

}
