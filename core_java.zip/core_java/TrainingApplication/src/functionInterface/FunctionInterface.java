package functionInterface;
import java.util.function.*;

public class FunctionInterface {
 static String show(String message)
 {
	 return "aaaa";
 }
 public static void main(String[] args) {
	Function<String,String> f=FunctionInterface::show;
	 
	 
	 System.out.println(f.apply("bbbb"));
}
}

