package functionInterface;

import java.util.function.*;

public class BifunctionExample {
	public static void main(String[] args) {
		BiFunction<String, String, String> bi = (x, y) -> {
			return (x + y);
		};
		System.out.println(bi.apply("sass","nnn"));
	}
}
