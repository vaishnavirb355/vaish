package functionInterface;
import java.util.function.*;
public class ConsumerExample {
	static void printMessage(String name)
	{
		System.out.println("hello"+name);
	}
	static void printValue(int val)
	{
		System.out.println(val);
	}
   
   public static void main(String[] args) {
	
	  Consumer<String> consumer1=ConsumerExample::printMessage;
	  consumer1.accept(" vaishnavi");
	  Consumer<Integer> consumer2=ConsumerExample::printValue;
	  consumer2.accept(100);
   }
}
