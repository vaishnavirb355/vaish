package Constructor;

public class person {
	public String name;
	public int age;
	public String address;
	
	
	public person()
	{
		name="vaishnavi";
		age=22;
		address="mangalore";
	}
	public person(String name,int age,String address)
	{
		this.name="rahul";
		this.age=23;
		this.address="rajasthan";
	}
	public person(String n,int a)
	{
		name=n;
		age=a;
	}
	
	

}
