package Constructor;

public class test {

	public static void main(String[] args) 
	{
	  person p1=new person();
	  System.out.println(p1.name+" "+p1.age+" "+p1.address);
	   
	  person p2=new person("aaa",23,"hgggg");
	  System.out.println(p2.name+" "+p2.age+" "+p2.address);
	  person p3=new person("bbb",23);
	  p3.address="bihar";
	  
	  System.out.println(p3.name+" "+p3.age+" "+p3.address);
	}

}
