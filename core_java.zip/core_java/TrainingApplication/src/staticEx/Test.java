package staticEx;

public class Test {

	public static void main(String[] args) {
	   Product p1=new Product();
	   Product p2=new Product();
	   Product p3=new Product();
	   Product p4=new Product();
	   System.out.println(p1.num);
	   System.out.println(Product.counter);
	   System.out.println(p2.num);
	   System.out.println(Product.counter);
	   System.out.println(p3.num);
	   System.out.println(Product.counter);
	   System.out.println(p4.num);
	   System.out.println(Product.counter);
	   
	  
	   System.out.println(Product.statmethod());
	}
}
