package staticEx;

public class Product {
	public String name;
	public static int counter=0;
	public static String brandname="Redmi";
	public int num;
	
	
	public Product()
	{
		counter++;
		num++;
		
	}
	public static int statmethod()
	{
		counter=counter+2;
		return counter;
	}

}
