package conditions;

public class leap_year {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     /*int year=1900;
     if(year%4==0)
    		 {
    	        if((year%100)!=0)
    	        {
    	        	System.out.println("year"+" "+year+"is a leap year");
    	        }
    	        if((year%400)==0)
    	        {
    	        	System.out.println("year"+" "+year+"is a leap year");
    	        }
    	       
    		 }
     else
     {
     	System.out.println("year"+year+"is not a leap year");
     }
	}*/

   /* int num=101;
    if(num%2==0)
    {
    System.out.println("num"+" "+num+" "+"is a even number");
    }
    else
    {
    System.out.println("num"+" "+num+" "+"is a odd number");
    }*/
		
		/*String ops="/";
		int a=10,b=20;
		switch(ops)
		{
		case "+": System.out.println("The value is"+" "+(a+b));
		        break;
		        
		case "-": System.out.println("The value is"+" "+(a-b));
                 break;
                 
		case "*":System.out.println("The value is"+" "+(a*b));
                  break;
                  
		case "/": System.out.println("The value is"+" "+(a/b));
                  break;
                  
        default: System.out.println("The operator used is not valid");*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
                
		}
    
    
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
