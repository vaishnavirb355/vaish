package conditions;

class conditions_test {

	public static void main(String[] args) 
	{
		System.out.println("printing x");
		int x=0;
		do {
			x++;
		}while(x<=10);
		
		System.out.println("priniting y");
		int y=0;
		while(y<=10)
			{
			System.out.println(y);
			y++;
		}
		
		System.out.println("priniting a");
		for(int a=0;a<10;a++)
		{
			System.out.println("*");
		}
	}

}
