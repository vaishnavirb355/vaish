package conditions;

public class conditions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20,c=20;
		
		if(a>b && a>c)
		{
			System.out.println("a is greater than b and c");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is greater than a and c");
		}
		else
		{
			System.out.println("c is greater than a and b");
		}


	}

}
