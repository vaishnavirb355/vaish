package login;
 
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
public class PersondaoImpl 
{
	Connection con=null;
	Statement st1=null;
	Statement st2=null;
	ResultSet rs=null;
	
	private Connection getConnection() throws SQLException
	{
		Connection con;
		con=ConnectionFactory.getInstance().getConnection();
		return con;
	}	
	}

