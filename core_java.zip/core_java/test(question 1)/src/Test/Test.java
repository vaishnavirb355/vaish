package Test;

import login.PersondaoImpl;

public class Test {
	public static void main(String[] args) {
		PersondaoImpl person=new PersondaoImpl();
		
	}

}
