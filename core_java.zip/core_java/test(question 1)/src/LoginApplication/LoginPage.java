package LoginApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class LoginPage {

	
	public static void main(String[] args) 
	{
		try {
			Scanner scn=new Scanner(System.in);
		 String uname="root";
		 String pass="1234";
		 String url="jdbc:mysql://localhost:3306/vaishnavi?useSSL=false";
		 Class.forName("com.mysql.cj.jdbc.Driver");	
		 Connection con=DriverManager.getConnection(url,uname,pass);
		 System.out.println("**************************************Welcome to the application**************************************");
		 System.out.println("-------------------------------------------LOGIN PAGE--------------------------------------------------------");
		 
		 //enter the username
		 System.out.println("Enter the username");
		 String temp_name=scn.next();
		 System.out.println("Enter the email");
		 String temp_email=scn.next();
		 String query="select username,email from users";
		 Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery(query);
		 
		 //enter the emailid
		
		while( rs.next())
		{
			System.out.println("entered");
		 if(((rs.getString("username").equals(temp_name))&&(rs.getString("email").equals(temp_email))))
		 {
			 System.out.println("VALID USER");
			System.out.println("Logged in successfully");
			break;
			 
		 }
		 else
		 {
			 System.out.println("Invalid username and email");
			 break;
		 }
		}

	}
		catch(Exception e)
		{
		System.out.println(e);	
		}	
}
}
