package src.org.slk;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;



@Path("/showroom")
public class Brands {
	@GET
	@Path("/getBrands")
	@Produces(MediaType.TEXT_PLAIN)
	public String getBrands() {
		return "listing the brand names";
	}
	@POST
	@Path("/setBrands")
	@Produces(MediaType.TEXT_PLAIN)
	public String setBrands() {
		return "Add a new brand";
	}

}
