package src.org.slk;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import src.org.slk.model.User;

@Controller
public class MainController {
	
	/*@RequestMapping(value="/",method=RequestMethod.GET)
	public String welcome() {
		return "HelloWorld";
	}
	@RequestMapping("displayName")
	public String displayName(HttpServletRequest request) 
	{
		String firstName=request.getParameter("firstName");
		request.setAttribute("firstName", firstName);
		return "displayName";		
	//}
	@GetMapping("displayname")
	public ModelAndView displayName(@RequestParam("firstName")String firstName) {
		ModelAndView modelAndView=new ModelAndView("displayName");
		Date date=new Date();
		List<String> names=new ArrayList<>();
		names.add("vaishnavi");
		names.add("aaaa");
		names.add("bbbb");
		names.add("cccc");
		
		modelAndView.addObject("date",date);
		modelAndView.addObject("name",firstName);
		modelAndView.addObject("team",names);
		return modelAndView;
		*/
	//}
	
	@GetMapping("/")
	public ModelAndView home() {
		ModelAndView modelAndView =new ModelAndView("userFormView");
		User user=new User();
		modelAndView.addObject("user",user);
		return modelAndView;
	}
	
	@PostMapping("/displayUserInfo")
	public ModelAndView displayUserInfo(@ModelAttribute User user) {
		ModelAndView modelAndView =new ModelAndView("displayUserInfo");
	    System.out.println(user);
	    modelAndView.addObject("user",user);
	    return modelAndView;
	}
}
