import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{HomeComponent} from './home/home.component';
import {EmployeeComponent} from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import{ContactusComponent} from './contactus/contactus.component';

const routes: Routes = [
{path:"home",component:HomeComponent},
{path:"department", component:DepartmentComponent},
{path:"employee", component:EmployeeComponent},
{path:"contactus",component:ContactusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const  RoutingComponent=[HomeComponent,ContactusComponent];
