import { Component, OnInit } from '@angular/core';
import {User} from '../user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

topics=['Angular','Java','JS','TS','SQL'];
  userModel=new User('vaishu','vaish@gmail.com',1234567890,'','morning',true);
  constructor() { }

  ngOnInit() {
  }

}
