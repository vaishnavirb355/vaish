import { Component, OnInit } from '@angular/core';
import{DataService} from '../data.service';
@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
 users:object;
  constructor( private data:DataService) { }
  
  ngOnInit() {
  	this.data.getUsers().subscribe(data=>{
  		this.users=data
  		console.log(this.users);
  	  }
  	);
  }

  firstClick(){
	this.data.firstClick();
 }
}
