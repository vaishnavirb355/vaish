import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignInComponent } from './sign-in/sign-in.component';
import {SignUpComponent } from './sign-up/sign-up.component';
import { ProductInfoComponent } from './product-info/product-info.component';
/*import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';*/


const routes: Routes = [
{path:'',redirectTo:'Products',pathMatch:'full'},
{path:'Customer', component:SignInComponent},
{path: 'dashboard',component:SignUpComponent},
{path: 'Customers',component:SignUpComponent },
{path: 'Products',component:ProductInfoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
