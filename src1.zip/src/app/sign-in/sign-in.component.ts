import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { LoginService } from '../login.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
	getdata:boolean;
	/*model:any = {};*/
	customer = new Customer();
	email:string;
	password:string;

  constructor(private _httpService: LoginService, private router: Router, private route:ActivatedRoute) { }

  ngOnInit() {
  }

  login(){
  	var mail = this.customer.email;
  	var pass = this.customer.password;
  	console.log(mail);
  	console.log(pass);
  	this._httpService.getDetails(mail, pass).subscribe((res:boolean) => {
  		console.log(res);
  		this.getdata = res;
  		console.log("flag" + this.getdata);
  	});

  	if(this.getdata == true){
  		console.log("this.getdata");
  		console.log("inside if");
  		this.router.navigate(['/dashboard']);
  	}
  }
  gotoList(){
  	this.router.navigate(['/Customer']);
  }
  }

