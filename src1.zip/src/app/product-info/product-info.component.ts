import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { ProductInfo } from './../product-info';

@Component({
  selector: 'app-product-info',
  templateUrl: './product-info.component.html',
  styleUrls: ['./product-info.component.css']
})
export class ProductInfoComponent implements OnInit {
	products: Observable<ProductInfo[]>;

  constructor(private loginService:LoginService, private router:Router) { }

  ngOnInit() {
  	this.reloadData();

  }

  reloadData(){
  this.products = this.loginService.getProduct();
  }

}


