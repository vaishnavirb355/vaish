import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
	customer = new Customer();
	submitted = false;

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {
  }

 newEmployee() : void{
  	this.submitted = false;
  	this.customer = new Customer();
  }

  save(){
  	this.loginService.createCustomer(this.customer)
  	.subscribe(data => console.log(data),error => console.log(error));
  	this.customer=new Customer();
  	this.gotoList();
  }

  onSubmit(){
  	this.submitted=true;
  	this.save();
  }

  gotoList(){
  	this.router.navigate(['/Customers']);
  }
}
