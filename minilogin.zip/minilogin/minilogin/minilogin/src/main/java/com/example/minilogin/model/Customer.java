package com.example.minilogin.model;

public class Customer {
	private int id;
	private boolean active;
	private String username;
	private String password;
	private String email;
	private String address;
	private long phone;
	private String role;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Customer() {
		super();
	}
	public Customer(int id, String username, String password, String email, long phone,String address,String role,boolean active) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.address=address;
		this.role=role;
		this.active=active;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", active=" + active + ", username=" + username + ", password=" + password
				+ ", email=" + email + ", address=" + address + ", phone=" + phone + ", role=" + role + "]";
	}
	
	
	

}
