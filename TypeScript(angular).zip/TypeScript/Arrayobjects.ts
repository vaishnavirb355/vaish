let j:any;
let arr:string[]=new Array("vaishnavi","says","hello");
for(var i=0;i<arr.length;i++)
{
	console.log(arr[i]);
}

console.log("***************");
for(j in arr)
{
	console.log(arr[j]);
}