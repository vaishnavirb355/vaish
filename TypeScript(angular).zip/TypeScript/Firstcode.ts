function hello(person)
{
	return"Hello,"+ person;
}
let user="vaishnavi";
console.log(hello(user));