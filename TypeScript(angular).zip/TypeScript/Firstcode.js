function hello(person) {
    return "Hello," + person;
}
var user = "vaishnavi";
console.log(hello(user));
