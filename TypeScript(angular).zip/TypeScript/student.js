var student = /** @class */ (function () {
    function student(firstname, middlename, lastname) {
        this.firstname = firstname;
        this.middlename = middlename;
        this.lastname = lastname;
        this.fullname = firstname + " " + middlename + " " + lastname;
    }
    return student;
}());
function message(person) {
    return "Hello," + person.firstname + " " + person.lastname;
}
var user = new student("vaishnavi", "r", "b");
console.log(message(user));
