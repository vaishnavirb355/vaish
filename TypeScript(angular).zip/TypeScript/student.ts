class student{
	fullname:string;
	constructor(public firstname:string,
		        public middlename:string,
		        public lastname:string)
	{
	this.fullname=firstname+" "+middlename+" "+lastname;
    }
}
interface Person
{
	firstname:string;
	lastname:string;
}
function message(person:Person)
{
    return "Hello,"+person.firstname+" "+person.lastname;
}
let user= new student("vaishnavi","r","b");
console.log(message(user));