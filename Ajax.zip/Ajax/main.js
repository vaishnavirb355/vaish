var teamInfo=document.getElementById("info");
var btn=document.getElementById("btn");

btn.addEventListener("click",function(){
  var ourRequest= new XMLHttpRequest();
  ourRequest.open('GET','https://learnwebcode.github.io/json-example/animals-1.json');
  ourRequest.onload=function()
  {
  	console.log(ourRequest.responseText);
  	var ourData=ourRequest.responseText;
  	var ourData=JSON.parse(ourRequest.responseText);
  	renderHTML(ourData);
  }
ourRequest.send();

function renderHTML(data)
{
	var htmlstring="";
  for(i=0;i<data.length;i++)
  {
    htmlstring+="<p>"+data[i].name+" is a "+data[i].species+" ,likes to eat ";
    for (j=0;j<data[i].foods.likes.length;j++)
    {
    	if(j==0)
    	{
    		htmlstring+=data[i].foods.likes[j];
    	}
    	else
    	{
    		htmlstring+=" and "+data[i].foods.likes[j];
    	}
    }
    htmlstring+=" and dislikes ";
    for(k=0;k<data[i].foods.dislikes.length;k++)
    {
    	if(k==0)
    	{
    		htmlstring+=data[i].foods.dislikes[k];
    	}
    	else
    	{
    		htmlstring+=" and "+data[i].foods.dislikes[k];
    	}
    }
    htmlstring+='.</p>';
  }
  info.insertAdjacentHTML('beforeend',htmlstring);
}

});