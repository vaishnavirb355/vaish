import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-samplesite',
  templateUrl: './samplesite.component.html',
  styleUrls: ['./samplesite.component.css']
})
export class SamplesiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
