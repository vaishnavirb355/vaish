import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forcomp',
  templateUrl: './forcomp.component.html',
  styleUrls: ['./forcomp.component.css']
})
export class ForcompComponent{
title='names title'
names=['neha','shazi','pc'];
name='';

addnames()
 {
		this.names.push(this.name);
  }
}
